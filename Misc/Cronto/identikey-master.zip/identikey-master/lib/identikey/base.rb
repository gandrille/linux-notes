module Identikey

  class Base
    extend Savon::Model

    def self.configure(&block)
      self.client.globals.instance_eval(&block)

      # Work around a sillyness in Savon
      if client.globals[:wsdl] != client.wsdl.document
        client.wsdl.document = client.globals[:wsdl]
      end
    end

    def self.client(options = nil)
      return super() unless options

      options = DEFAULTS.merge(options)
      options = process_identikey_filters(options)

      super options
    end

    def self.default_user_agent_header
      {'User-Agent' => "ruby/identikey #{Identikey::VERSION}"}
    end

    # Loops over the filters option content and adds Identikey
    # specific parameter filtering.
    #
    # Due to faulty design in the Identikey SOAP endpoint, the
    # parameter filters require context-dependant logic as all
    # attributes are passed in `<attributeID>` elements, while
    # all values are passed in `<value>` elements.
    #
    # Identikey attributes to filter out are specified in the
    # `filters` option with the `identikey:` prefix.
    #
    # Example, filter out the `CREDFLD_PASSWORD` field from
    # the logs (done by default):
    #
    # configure do
    #   filters [ 'identikey:CREDFLD_PASSWORD' ]
    # end
    #
    def self.process_identikey_filters(options)
      filters = options[:filters] || []

      options[:filters] = filters.map do |filter|
        if filter.to_s =~ /^identikey:(.+)/
          filter = identikey_filter_proc_for($1)
        end

        filter
      end

      return options
    end

    def self.identikey_filter_proc_for(attribute)
      lambda do |document|
        document.xpath("//attributeID[text()='#{attribute}']/../value").each do |node|
          node.content = '***FILTERED***'
        end
      end
    end

    DEFAULTS = {
      endpoint: 'https://localhost:8888/',

      ssl_version: :TLSv1_2,
      ssl_verify_mode: :none,

      headers: default_user_agent_header,

      encoding: 'UTF-8',

      logger: Logger.new('log/identikey.log'),
      log_level: :debug,
      log: true,
      pretty_print_xml: true,

      filters: [
        'sessionID',
        'staticPassword',
        'identikey:CREDFLD_PASSWORD',
        'identikey:CREDFLD_STATIC_PASSWORD',
        'identikey:CREDFLD_SESSION_ID'
      ]
    }.freeze

    def endpoint
      self.class.client.globals[:endpoint]
    end

    def wsdl
      self.class.client.globals[:wsdl]
    end

    protected

      # Parse the generic response types that the API returns.
      #
      # The returned attributes in the Administration API are:
      #
      # - The given root element, whose name is derived from the SOAP command
      #   that was invoked
      # - The :results element, containing:
      #   - :result_codes, containing :status_code_enum that is the operation
      #     result code
      #   - :result_attribute, that may either contain a single attributes list
      #      or multiple ones.
      #   - :error_stack, a list of error that occurred
      #
      # The authentication API wraps the results element in another one
      #
      # The provisioning API uses a status element for the result code and
      # error stack, and a result element for the results.
      #
      # The returned value is a three-elements array, containing:
      #
      #   [Response code, Attribute(s) list, Errors list]
      #
      # The response code is a string from the IDENTIKEY Authentication Server
      # Error Codes table.
      #
      # The attributes list is an Hash when a single object's attributes were
      # requested, or is an Array of Hashes when the response contains a list
      # of objects.
      #
      # The attributes list may be nil.
      #
      # The errors list is an array of strings containing error descriptions.
      # The strings themselves contain the error code, albeit in different
      # formats. TODO maybe create a separate class for errors, that includes
      # the error code.
      #
      def parse_response(resp, root_element)
        root = parse_result_root(resp.body, root_element)

        results = parse_result_element(root, root_element)

        result_code       = parse_result_code(results, root_element)
        result_attributes = parse_result_attributes(results, root_element)
        result_errors     = parse_result_errors(results, root_element)

        return result_code, result_attributes, result_errors
      end

      def parse_result_root(body, root_element)
        if body.size.zero?
          raise Identikey::ParseError, "Empty response received"
        end

        unless body.key?(root_element)
          raise Identikey::ParseError, "Expected response to have #{root_element}, found #{body.keys.join(', ')}"
        end

        # The root results element
        #
        return body[root_element]
      end

      def parse_result_element(root, root_element)
        # The results element
        #
        unless root.key?(:results)
          raise Identikey::ParseError, "Results element not found below #{root_element}"
        end

        return root[:results]
      end

      def parse_result_code(results, root_element)
        unless results.key?(:result_codes)
          raise Identikey::ParseError, "Result codes not found below #{root_element}"
        end

        results[:result_codes][:status_code_enum] || 'STAT_UNKNOWN'
      end

      def parse_result_attributes(results, root_element)
        unless results.key?(:result_attribute)
          raise Identikey::ParseError, "Result attribute not found below #{root_element}"
        end

        results_attr = results[:result_attribute]

        if results_attr.key?(:attributes)
          entries = [ results_attr[:attributes] ].flatten
          parse_attributes entries

        elsif results_attr.key?(:attribute_list)
          # This attribute may contain a single entry or multiple ones. Lists of
          # a single element are returned as a single attributes set.. but the
          # caller expects a list so we return the single element in an Array.
          #
          entries = [ results_attr[:attribute_list] ].flatten
          entries.inject([]) do |a, entry|
            a.push parse_attributes(entry[:attributes])
          end
        else
          nil
        end
      end

      def parse_result_errors(results, root_element)
        if results[:error_stack].key?(:errors)
          parse_errors results[:error_stack][:errors]
        else
          nil
        end
      end

      def parse_attributes(attributes)
        attributes.inject({}) do |h, attribute|
          h.update(attribute.fetch(:attribute_id) => attribute.fetch(:value))
        end
      end

      def parse_errors(errors)
        case errors
        when Array
          errors.map { |e| e.fetch(:error_desc) }
        when Hash
          errors.fetch(:error_desc)
        end
      end

      def typed_attributes_list_from(hash)
        self.class.typed_attributes_list_from(hash)
      end

      # Calls typed_attribute_query_list_from() by removing the
      # nil values from the given hash.
      #
      # The nil values are ignored when calling API endpoints that
      # are not query ones, as such there is no point in adding an
      # attributeOption null:true on those.
      #
      def self.typed_attributes_list_from(hash)
        typed_attributes_query_list_from(hash.reject {|k,v| v.nil?})
      end

      def typed_attributes_query_list_from(hash)
        self.class.typed_attributes_query_list_from(hash)
      end

      # Converts and hash keyed by attribute name into an array of hashes
      # whose keys are the attribute name as attributeID and the value as
      # a Gyoku-compatible hash with the xsd:type annotation. The type is
      # inferred from the Ruby value type and the contents are serialized
      # as a string formatted as per the XSD DTD definition.
      #
      # Further, this supports "virtual" attributes with a "NOT_" prefix.
      # If the NOT_ prefix is set to the attribute name then the negative
      # attributeOption is set.
      #
      # <rant>
      # This code should not exist, because defining argument types is what
      # WSDL is for.  However, in the braindead web services implementation
      # of Vasco there are infinite protocols that accept a variable number
      # of attributes and their types are defined only in the documentation
      # and in server code, making WSDL (and SOAP) only an annoynace rather
      # than an aid.
      # </rant>
      #
      def self.typed_attributes_query_list_from(hash)
        hash.map do |full_name, value|

          parse = /^(not_)?(.*)/i.match(full_name.to_s)
          name  = parse[2]

          options = {}
          options[:negative] = true if !parse[1].nil?

          type, value = case value

          when Unsigned
            [ 'xsd:unsignedInt', value.to_s ]

          when Integer
            [ 'xsd:int', value.to_s ]

          when Time
            [ 'xsd:dateTime', value.utc.iso8601 ]

          when TrueClass, FalseClass
            [ 'xsd:boolean', value.to_s ]

          when Symbol, String
            [ 'xsd:string', value.to_s ]

          when NilClass
            options[:null] = true
            [ 'xsd:string', '' ]

          else
            raise Identikey::UsageError, "#{full_name} type #{value.class} is unsupported"
          end

          { attributeID:      name,
            attributeOptions: options,
            value: { '@xsi:type': type, content!: value } }
        end.compact
      end

      # Translates the given attributes map into an hash suitable to be passed
      # to typed_attributes_query_list_from(). This is used only to DRY the
      # invocations across the _query methods.
      #
      def self.search_attributes_from(query, attribute_map:)
        query.inject({}) do |ret, (key, value)|

          parse  = /^(not_)?(.*)/.match(key.to_s)
          negate = !parse[1].nil?
          name   =  parse[2]

          attribute = attribute_map.fetch(name, nil)

          if attribute.nil?
            raise Identikey::UsageError, "Invalid search key: #{key}"
          end

          attribute = "NOT_#{attribute}" if negate

          ret.update(attribute => value)
        end
      end

      # Translate our search interface options into Identikey's _query methods
      # interface options.
      #
      def self.search_options_from(options)
        options.inject({}) do |ret, (option, value)|
          attribute = {
            'distinct' => 'distinct',
            'limit'    => 'rowcount',
            'offset'   => 'rowoffset',
          }.fetch(option.to_s, nil)

          if attribute.nil?
            raise Identikey::UsageError, "Invalid search option: #{option}"
          end

          ret.update(attribute => value)
        end
      end

    # protected

  end

end
