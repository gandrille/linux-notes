require 'savon'

require 'identikey/version'
require 'identikey/error'
require 'identikey/unsigned'
require 'identikey/authentication'
require 'identikey/administration'
require 'identikey/provisioning'
