RSpec.describe Identikey do
  it "has a version number" do
    expect(Identikey::VERSION).not_to be nil
  end
end
