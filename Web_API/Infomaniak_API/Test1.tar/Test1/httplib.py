import base64


def get_method(event):
    try:
      return event['requestContext']['http']['method']
    except:
      return event['requestContext']['httpMethod']
      

def get_basic_auth(event):
  try:
    reqHeaders = event['headers']
    auth = reqHeaders['authorization']
    if auth.startswith("Basic ") or auth.startswith("basic "):
      auth = auth[6:]
    return base64.b64decode(auth).decode('ascii')
  except:
    return ""


def decode_body(event):
    # Fetching body
    try:
        body = event['body']
    except:
        return {}
    
    # Decoding body
    result = {}
    str = base64.b64decode(body).decode('iso-8859-1')
    tokens = str.split('&')
    for token in tokens:
        kv = token.split("=", 1)
        key = kv[0]
        val = kv[1]
        result[key] = val
    return result
