import json
import urllib.request
import httperror


class InfomaniakSieveManager:

  def __init__(self, config):
    self.config = config
  
  def download(self):
    res = urllib.request.urlopen(urllib.request.Request(
      url=f"https://api.infomaniak.com/1/mail_hostings/{self.config.hosting_id}/mailboxes/{self.config.mailbox}/auth/filters",
      headers=self.get_headers(),
      method='GET'),
    timeout=5)
    scripts = json.loads(res.read())['data']['scripts']
    for script in scripts:
      if script['name'] == self.config.scriptName:
        return script['content']
    raise httperror.HTTPError(404, f"script {self.scriptName} can not be retreived")
  
  def upload(self, content):
    data = {
      "name": self.config.scriptName,
      "old_name": self.config.scriptName,
      "content": content,
      "is_enabled": True
    } 
    data = json.dumps(data).encode('utf-8')
    res = urllib.request.urlopen(
      urllib.request.Request(
        url=f"https://api.infomaniak.com/1/mail_hostings/{self.config.hosting_id}/mailboxes/{self.config.mailbox}/auth/filters/scripts",
        headers=self.get_headers(),
        method='PATCH'),
      data=data,
      timeout=5)

  def get_headers(self):
    return {
      'Authorization': 'Bearer ' + self.config.token,
      'content-type': 'application/json'
    } 

class InfomaniakSieveConfig:
  def __init__(self, token, hosting_id, mailbox, scriptName):
    self.token = token
    self.hosting_id = hosting_id
    self.mailbox = mailbox
    self.scriptName = scriptName
