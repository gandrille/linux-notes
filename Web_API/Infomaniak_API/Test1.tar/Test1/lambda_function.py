import infomaniakaliasdb
import infomaniaksievemanager
import sievemodel
import htmlcontent
import httperror

import random
import httplib
import os


# Env variables
token       = os.environ['INFOMANIAK_TOKEN']
hosting_id  = os.environ['INFOMANIAK_HOSTING_ID']
mailbox     = os.environ['INFOMANIAK_MAILBOX']
scriptName  = os.environ['INFOMANIAK_SCRIPT_NAME']

domain      = os.environ['DOMAIN']

webUsername = os.environ['UI_USERNAME']
webPassword = os.environ['UI_PASSWORD']


def lambda_handler(event, context):
  # password checking
  if httplib.get_basic_auth(event) != f"{webUsername}:{webPassword}":
    return {
      'statusCode': 401,
      'headers': {
        'www-authenticate': 'Basic realm="Restricted Area"'
      }
    }

  # Domain objects
  dbconfig = infomaniakaliasdb.InfomaniakAliasConfig(token, hosting_id, mailbox)
  db = infomaniakaliasdb.InfomaniakAliasDB(dbconfig)
  managerconfig = infomaniaksievemanager.InfomaniakSieveConfig(token, hosting_id, mailbox, scriptName)
  manager = infomaniaksievemanager.InfomaniakSieveManager(managerconfig)
  originalScript = manager.download()

  # Initial data
  aliases = db.getAll()
  sieveModel = sievemodel.SieveModel(originalScript)
  messages = []

  # Creating new alias if needed
  request = httplib.decode_body(event)
  try:
    newAlias = request['alias']
  except:
    newAlias = None

  if newAlias is not None:
    if len(newAlias) < 3:
      messages.append(htmlcontent.Message("error", f"{newAlias} is too short"))
    elif db.exists(newAlias):
      messages.append(htmlcontent.Message("error", f"{newAlias} already exists"))
    elif len(db.findStartingWith(f"{newAlias}-")) != 0:
      foundAlias = db.findStartingWith(f"{newAlias}-")[0]
      messages.append(htmlcontent.Message("error", f"{foundAlias} already exists"))
    else:
      try:
        nb = random.randrange(100000, 999999)  
        newAlias=f"{newAlias}-{nb}"
        newCategory = request['category']

        db.create(newAlias)
        aliases.append(newAlias)
        sieveModel.addAlias(newAlias)
        sieveModel.addRedirection(newAlias, newCategory, False)
        manager.upload(sieveModel.generateScript())
        
        msg = f"<div class='alert-primary'>{newAlias}@{domain} <button onclick=\"navigator.clipboard.writeText('{newAlias}@{domain}');\">📋</button> was created with category {newCategory}</div>"
        messages.append(htmlcontent.Message("info", msg))
      except httperror.HTTPError as err:
        msg = f"<div class='error'>{newAlias} was not created: {err.message}</div>"
        messages.append(htmlcontent.Message("error", msg))

  # result
  sieveModel.updateAliasList(aliases)
  sieveScript = sieveModel.generateScript()
  folders = sieveModel.getFolders()
  htmlModel = htmlcontent.HtmlModel(sieveModel.getRedirectionsWithValidAliases(), folders, sieveScript, messages)
  htmlWriter = htmlcontent.HtmlWriter()
  htmlContent = htmlWriter.toHtml(htmlModel)
  
  return {
    'statusCode': 200,
    'headers': {
      'Content-Type': 'text/html'
    },
    'body': htmlContent
  }
