import json
import urllib.request
import httperror


class InfomaniakAliasDB():
  def __init__(self, config):
    self.config = config

  def getAll(self):
    res = urllib.request.urlopen(urllib.request.Request(
      url=f"https://api.infomaniak.com/1/mail_hostings/{self.config.hosting_id}/mailboxes/{self.config.mailbox}/aliases",
      headers=self.get_headers(),
      method='GET'),
    timeout=5)
    return json.loads(res.read())['data']['aliases']

  def findStartingWith(self, prefix):
    aliases = self.getAll()
    filtered = filter(lambda alias: alias.startswith(prefix), aliases)
    return list(filtered)

  def exists(self, alias):
    aliases = self.getAll()
    return alias in aliases

  def create(self, alias):
    data = { 'alias': alias }
    data = json.dumps(data)
    data = str(data)
    data = data.encode('utf-8')
    try:
      res = urllib.request.urlopen(urllib.request.Request(
        url=f"https://api.infomaniak.com/1/mail_hostings/{self.config.hosting_id}/mailboxes/{self.config.mailbox}/aliases",
        headers=self.get_headers(),
        method='POST'),
      data=data,
      timeout=5)
      return json.loads(res.read())
    except:
      raise httperror.HTTPError(403, f"Alias {alias} already exists")

  def delete(self, alias):
    try:
      res = urllib.request.urlopen(urllib.request.Request(
        url=f"https://api.infomaniak.com/1/mail_hostings/{self.config.hosting_id}/mailboxes/{self.config.mailbox}/aliases/{alias}",
        headers=self.get_headers(),
        method='DELETE'),
      timeout=5)
      return json.loads(res.read())
    except:
      raise httperror.HTTPError(404, f"Alias {alias} does not exist, therefore it can't be deleted")

  def get_headers(self):
    return {
      'Authorization': 'Bearer ' + self.config.token,
      'content-type': 'application/json'
    }    

class InfomaniakAliasConfig:
  def __init__(self, token, hosting_id, mailbox):
    self.token=token
    self.hosting_id=hosting_id
    self.mailbox=mailbox

