class HTTPError(Exception):
  def __init__(self, code, message=""):
    self.code = code
    self.message = f"HTTP code {code} {message}"
    super().__init__(self.message)
