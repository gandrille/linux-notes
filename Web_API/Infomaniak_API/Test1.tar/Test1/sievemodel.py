import httperror

class SieveModel:
    
  def __init__(self, scriptContent=""):
    self.aliases = []
    self.redirections = {}
    for line in scriptContent.split('\n'):
      if line.startswith('# fileinto'):
        tokens = line.split(" ")
        folder = tokens[2]
        aliases = ' '.join(tokens[3:]).strip().split()
        for alias in aliases:
          self.aliases.append(alias)
          self.redirections[alias] = folder


  # Aliases
  # =======

  def existAlias(self, alias):
    return alias in self.aliases

  def addAlias(self, alias, failsIfAlreadyExists=True):
    if self.existAlias(alias):
      if failsIfAlreadyExists:
        raise httperror.HTTPError(409, f"Alias {alias} already exists")
    else:
      self.aliases.append(alias)

  def deleteAlias(self, alias, failsIfNotExists=True):
    if not self.existAlias(alias):
      if failsIfNotExists:
        raise httperror.HTTPError(409, f"Alias {alias} does not exist")
    else:
      self.aliases.remove(alias)

  def updateAliasList(self, aliases):
    self.aliases = aliases


  # Redirections
  # ============

  def existRedirection(self, alias):
    try:
      self.redirections[alias]
      return True
    except:
      return False

  def getRedirectionFolder(self, alias):
    return self.redirections[alias]

  def getRedirectionsWithValidAliases(self):
    result = {}
    for alias in self.redirections:
      if self.existAlias(alias):
        result[alias] = self.redirections[alias]
    return result

  def getRedirectionsAliasWithValidAliases(self, folder=None):
    aliases = []
    for alias, f in self.redirections.items():
      if ( folder is None or folder == f ) and self.existAlias(alias):
        aliases.append(alias)
    aliases.sort()
    return aliases
    
  def addRedirection(self, alias, folder, failsIfAlreadyExists=True):
    if failsIfAlreadyExists and self.existRedirection(alias):
      raise httperror.HTTPError(409, f"Redirection for {alias} already exists")
    self.redirections[alias] = folder

  def updateRedirection(self, alias, folder, failsIfNotExists=True):
    if failsIfNotExists and not self.existRedirection(alias):
      raise httperror.HTTPError(409, f"Redirection for {alias} does not exist")
    self.redirections[alias] = folder

  def deleteRedirection(self, alias, failsIfNotExists=True):
    if not self.existRedirection(alias):
      if failsIfNotExists:
        raise httperror.HTTPError(409, f"Redirection for {alias} does not exist")
    else:
      self.redirections.pop(alias)

  def getFolders(self):
    folders = []
    for alias, folder in self.redirections.items():
      if not folder in folders:
        folders.append(folder)
    folders.sort()
    return folders
    
    
  # Combined
  # ========
  
  def unknownAliasesInRedirections(self):
    results = []
    for alias in self.redirections:
      if not alias in self.aliases:
        results.append(alias)
    return results
    
  def aliasesWithoutRedirection(self):
    results = []
    for alias in self.aliases:
      try:
        self.redirections[alias]
      except:
        results.append(alias)
    return results


  # Script generator
  # ================
  
  def generateScript(self):
    content = "require [\"fileinto\", \"editheader\", \"variables\"];\n\n"

    withoutRedir = self.aliasesWithoutRedirection()
    if len(withoutRedir):
      content += "# The following alias do not have a redirection: " + " ".join(withoutRedir) + "\n\n"

    for folder in self.getFolders():
      aliases = ' '.join(self.getRedirectionsAliasWithValidAliases(folder))
      content += f"# fileinto {folder} {aliases}\n"
    content += '\n'
  
    content += 'if header :matches "Subject" "*" {\n'
    content += '    set "subject" "${1}";\n'
    content += '}\n\n'

    for alias, folder in sorted(self.redirections.items()):
      if self.existAlias(alias):
        try:
          idx = alias.rindex('-')
          key = alias[:idx]
        except Exception:
          key = alias

        content += "if header :contains [\"To\", \"Cc\", \"Bcc\"] [\"" + alias + "\"] {\n"
        content += "  deleteheader \"Subject\";\n"
        content += "  addheader :last \"Subject\" \"[" + key + "] ${subject}\";\n"
        content += "  fileinto \"" + folder + "\";\n"
        content += "}\n\n"

    return content

