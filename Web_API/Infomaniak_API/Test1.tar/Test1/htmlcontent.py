class HtmlModel:
    
  def __init__(self, redirections, folders, sieveScript, messages=[]):
    self.redirections = dict(sorted(redirections.items()))
    self.folders = folders
    self.sieveScript = sieveScript
    self.messages = messages
    
class HtmlWriter:

  def __init__(self):
    with open('index.html', 'r') as file:
      self.template = file.read()

  def messagesToHtml(self, messages):
    html = "";
    for message in messages:
      html += f"<div class='{message.classe}'>{message.message}</div>\n"
    return html

  def redirectionsToHtml(self, redirections):
    html = f"<p>{len(redirections)} redirections available</p>\n"
    html += '<ul>\n'
    for alias, folder in redirections.items():
      html += f"  <li>{alias} ({folder})</li>\n"
    html += '</ul>\n'
    return html

  def jsFoldersToHtml(self, folders):
    content = "<script>\n(function() {\n"
    content += "  var drop = document.getElementById(\"folder\");\n"
    for key in folders:
      content += f"  var {key} = document.createElement(\"option\");\n"
      content += f"  {key}.text = \"{key}\";\n"
      content += f"  drop.add({key});\n"
    content += "})();\n</script>\n"
    return content

  def toHtml(self, model):
    messages = self.messagesToHtml(model.messages)
    redirections = self.redirectionsToHtml(model.redirections)
    js = self.jsFoldersToHtml(model.folders)

    html = self.template
    html = html.replace("%messages%", messages)
    html = html.replace("%redirections%", redirections)
    html = html.replace("%sieve_content%", model.sieveScript)
    html = html.replace("%javascript_content%", js)

    return html


class Message:
  def __init__(self, classe, message):
    self.classe = classe
    self.message = message


