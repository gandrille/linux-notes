import requests
import httperror


class GandiAliasDB:
  def __init__(self, config):
    self.config = config
  
  def getAll(self):
    headers = {'authorization': f"Apikey {self.config.apikey}"}
    url = f"https://api.gandi.net/v5/email/mailboxes/{self.config.domain}/{self.config.mailboxId}"
    r = requests.get(url, headers=headers)
    if r.status_code != requests.codes.ok:
      raise httperror.HTTPError(r.status_code, "Error when retreiving alias list")
    return r.json()['aliases']

  def updateFullList(self, aliases):
    headers = {'authorization': f"Apikey {self.config.apikey}"}
    url = f"https://api.gandi.net/v5/email/mailboxes/{self.config.domain}/{self.config.mailboxId}"
    payload = { 'aliases': aliases }
    r = requests.patch(url, headers=headers, json=payload)
    if r.status_code != 202:
      raise httperror.HTTPError(r.status_code, f"Alias update list failed")
    return aliases

  def findStartingWith(self, prefix):
    aliases = self.getAll()
    filtered = filter(lambda alias: alias.startswith(prefix), aliases)
    return list(filtered)

  def exists(self, alias):
    aliases = self.getAll()
    return alias in aliases

  def create(self, alias):
    aliases = self.getAll()
    if alias in aliases:
      raise httperror.HTTPError(403, f"Alias {alias} already exists")
    aliases.append(alias)
    self.updateFullList(aliases)
    return aliases

  def delete(self, alias):
    aliases = self.getAll()
    if alias not in aliases:
      raise httperror.HTTPError(404, f"Alias {alias} does not exist, therefore it can't be deleted")
    aliases.remove(alias)
    self.updateFullList(aliases)
    return aliases

class GandiAliasConfig:
  def __init__(self, apikey, domain, mailboxId):
    self.apikey=apikey
    self.domain=domain
    self.mailboxId=mailboxId

