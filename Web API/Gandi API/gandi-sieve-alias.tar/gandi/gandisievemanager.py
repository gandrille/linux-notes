from sievelib.managesieve import Client
import requests
import httperror


class GandiSieveManager:

  def __init__(self, config):
    self.client = Client(config.server)
    self.client.connect(config.user, config.password, starttls=True, authmech="PLAIN")
    self.scriptName = config.scriptName
    scripts = self.client.listscripts()
    if not self.client.setactive(self.scriptName):
      raise httperror.HTTPError(404, f"script {self.scriptName} does not exist")
  
  def download(self):
    scriptContent = self.client.getscript(self.scriptName)
    if scriptContent is None:
      raise httperror.HTTPError(404, f"script {self.scriptName} can not be retreived")
    return scriptContent

  def upload(self, content):
    if not self.client.checkscript(content):
      raise httperror.HTTPError(412, f"script {self.scriptName} has an invalid content")
    if not  self.client.putscript(self.scriptName, content):
      raise httperror.HTTPError(400, f"script {self.scriptName} was not uploaded")

class GandiSieveConfig:
  def __init__(self, server, user, password, scriptName):
    self.server = server
    self.user = user
    self.password = password
    self.scriptName = scriptName

