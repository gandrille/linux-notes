*******
License
*******

Released under the MIT license below.

.. literalinclude:: ../../../LICENSE
