*******************************
Example Script: Animated Images
*******************************

The following is a complete example script to connect to attached StreamDeck
devices, and display animated graphics on the keys.

.. literalinclude:: ../../../src/example_animated.py
    :language: python
