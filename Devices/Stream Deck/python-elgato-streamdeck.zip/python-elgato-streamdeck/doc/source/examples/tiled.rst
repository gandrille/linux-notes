***************************
Example Script: Tiled Image
***************************

The following is a complete example script to display a larger image across a
StreamDeck, by sectioning up the image into key-sized tiles, and displaying
them individually onto each key.

.. literalinclude:: ../../../src/example_tileimage.py
    :language: python
