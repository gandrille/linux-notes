**********************************
Example Script: Device Information
**********************************

The following is a complete example script to enumerate any available StreamDeck
devices and print out all information on the device's location and image format.

.. literalinclude:: ../../../src/example_deckinfo.py
    :language: python
