***************************
Example Script: Basic Usage
***************************

The following is a complete example script to connect to attached StreamDeck
devices, display custom image/text graphics on the buttons and respond to press
events.

.. literalinclude:: ../../../src/example_basic.py
    :language: python
