*********************
Example Script: Pedal
*********************

The following is an example script to connect to the Stream Deck Pedal, and print whenever its buttons are pushed and released.

.. literalinclude:: ../../../src/example_pedal.py
    :language: python
